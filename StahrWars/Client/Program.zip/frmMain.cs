﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client {
    public struct Received {
        public IPEndPoint Sender;
        public string Message;
    }

    abstract class UdpBase {
        protected UdpClient Client;

        protected UdpBase() {
            Client = new UdpClient();
        }

        public async Task<Received> Receive() {
            var result = await Client.ReceiveAsync();
            return new Received() {
                Message = Encoding.ASCII.GetString(result.Buffer, 0, result.Buffer.Length),
                Sender = result.RemoteEndPoint
            };
        }
    }

    //Client
    class UdpUser : UdpBase {
        private UdpUser() { }

        public static UdpUser ConnectTo(string hostname, int port) {
            var connection = new UdpUser();
            connection.Client.Connect(hostname, port);
            return connection;
        }

        public void Send(string message) {
            var datagram = Encoding.ASCII.GetBytes(message);
            Client.Send(datagram, datagram.Length);
        }
    }


    public partial class frmMain : Form {
 
        static System.Drawing.Graphics graphicsObj;
        static Pen gridPen = new Pen(System.Drawing.Color.Blue, 2);
        static int gridSize = 20;
        static List<Point> points = new List<Point>();

        public frmMain() {
            InitializeComponent();

            graphicsObj = panCanvas.CreateGraphics();
            gridPen.DashPattern = new float[] { 1,1,1,1 };

            beginMessages();

        }

        private  void beginMessages() {
            UdpUser client = UdpUser.ConnectTo("172.25.54.151", 32123);

            string msg;
            string[] parts;
            Task.Factory.StartNew(async () => {
                while (true) {
                    try {
                        msg = (await client.Receive()).Message.ToString();
                        //this.Text = msg;
                        parts = msg.Split(':');
                        if (parts[0].ToLower().Equals("quit")) {
                            break;
                        } else if (parts[0].ToLower().Equals("block")) {
                            int x = gridSize * Convert.ToInt32(parts[1]);
                            int y = gridSize * Convert.ToInt32(parts[2]);
                            points.Add(new Point(x, y));
                            panCanvas.Invalidate();
                        }
                    } catch  {
                        //this.Text = ex.Message;
                    }
                }
                Environment.Exit(0);
            });

            client.Send("Connected:Mike");
        }

        private void panCanvas_Paint(object sender, PaintEventArgs e) {
            
            for (int i = gridSize; i < panCanvas.Height ; i += gridSize) {
                e.Graphics.DrawLine(gridPen, 0, i, panCanvas.Width, i);
                e.Graphics.DrawLine(gridPen, i, 0, i, panCanvas.Height);
            }

            foreach(Point p in points)
                e.Graphics.FillRectangle(Brushes.Red, p.X, p.Y, gridSize, gridSize);
        }

        private void panCanvas_MouseUp(object sender, MouseEventArgs e) {
            points.Add(new Point(gridSize * (e.X / gridSize), gridSize * (e.Y/gridSize)));
            int x = gridSize * (e.X / gridSize);
            int y = gridSize * (e.Y / gridSize);
            graphicsObj.FillRectangle(Brushes.Red, x, y, gridSize, gridSize); 
        }

       
    }
}
